import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Navigate,
} from "react-router-dom";
import UserRegister from "../auth/UserRegister";
import UserLogin from "../auth/UserLogin";
import FoodPartnerRegister from "../auth/FoodPartnerRegister";
import FoodPartnerLogin from "../auth/FoodPartnerLogin";
import ChooseRegister from "../auth/ChooseRegister";
import CreateFood from "../components/foodpartner/CreateFood";
import Profile from "../components/foodpartner/Profile";
import Dashboard from "../components/foodpartner/Dashboard";
import Home from "../components/Home";
import Saved from "../components/Saved";
import Reels from "../components/reels/Reels";
import SingleReel from "../components/reels/SingleReel";
import FoodPartnerLayout from "../layouts/FoodPartnerLayout";
import useAuthStore from "../store/authStore";

const AppRoute = () => {
  const { isAuthenticated, userType } = useAuthStore();

  return (
    <Router>
      <Routes>
        {/* Guest only routes - redirect to home if authenticated */}
        <Route
          path="/register"
          element={
            isAuthenticated ? (
              <Navigate
                to={userType === "foodpartner" ? "/create-food" : "/"}
                replace
              />
            ) : (
              <ChooseRegister />
            )
          }
        />
        <Route
          path="/user/register"
          element={
            isAuthenticated ? (
              <Navigate
                to={userType === "foodpartner" ? "/create-food" : "/"}
                replace
              />
            ) : (
              <UserRegister />
            )
          }
        />
        <Route
          path="/user/login"
          element={
            isAuthenticated ? (
              <Navigate
                to={userType === "foodpartner" ? "/create-food" : "/"}
                replace
              />
            ) : (
              <UserLogin />
            )
          }
        />
        <Route
          path="/food-partner/register"
          element={
            isAuthenticated ? (
              <Navigate
                to={
                  userType === "foodpartner" ? "/food-partner/dashboard" : "/"
                }
                replace
              />
            ) : (
              <FoodPartnerRegister />
            )
          }
        />
        <Route
          path="/food-partner/login"
          element={
            isAuthenticated ? (
              <Navigate
                to={
                  userType === "foodpartner" ? "/food-partner/dashboard" : "/"
                }
                replace
              />
            ) : (
              <FoodPartnerLogin />
            )
          }
        />

        {/* User only routes */}
        <Route
          path="/"
          element={
            isAuthenticated && userType === "user" ? (
              <Home />
            ) : (
              <Navigate to="/register" replace />
            )
          }
        />
        <Route
          path="/reels"
          element={
            isAuthenticated && userType === "user" ? (
              <Reels />
            ) : (
              <Navigate to="/register" replace />
            )
          }
        />
        <Route
          path="/reels/:reelId"
          element={
            isAuthenticated && userType === "user" ? (
              <SingleReel />
            ) : (
              <Navigate to="/register" replace />
            )
          }
        />
        <Route
          path="/saved"
          element={
            isAuthenticated && userType === "user" ? (
              <Saved />
            ) : (
              <Navigate to="/register" replace />
            )
          }
        />

        {/* Food partner only routes with layout */}
        <Route
          element={
            isAuthenticated && userType === "foodpartner" ? (
              <FoodPartnerLayout />
            ) : (
              <Navigate to="/food-partner/login" replace />
            )
          }
        >
          <Route path="/food-partner/dashboard" element={<Dashboard />} />
          <Route path="/create-food" element={<CreateFood />} />
        </Route>

        <Route path="/food-partner/:id" element={<Profile />} />
      </Routes>
    </Router>
  );
};

export default AppRoute;
